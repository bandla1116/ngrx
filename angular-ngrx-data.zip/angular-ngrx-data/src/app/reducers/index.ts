import { routerReducer } from "@ngrx/router-store";
import { ActionReducerMap, MetaReducer } from "@ngrx/store";
import { storeFreeze } from "ngrx-store-freeze";
import { environment } from "../../environments/environment";
import { User } from "../model/user.model";

type AuthState = {
  loggedIn: boolean;
  user: User;
};
export interface AppState {}
const initialAuthState: AuthState = {
  loggedIn: false,
  user: undefined
};
export const reducers: ActionReducerMap<AppState> = {
  router: routerReducer
};

export const metaReducers: MetaReducer<AppState>[] = !environment.production
  ? [storeFreeze]
  : [];
